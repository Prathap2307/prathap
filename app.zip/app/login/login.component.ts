import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

//import { ILogin } from '../login';
import { Hero } from '../hero';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

	
	  loginForm: FormGroup;
	  message: string;
	  returnUrl: string;
	  
	// HEROES: ILogin =  { userid: "qwerty", password: "123" }; 
	HEROES: Hero[] = [
	  { userid: '11', password: 'Nice' },
	  { userid: '12', password: 'Narco' },
	  { userid: '13', password: 'Bombasto' },
	  { userid: '14', password: 'Celeritas' },
	  { userid: '15', password: 'Magneta' },
	  { userid: '16', password: 'RubberMan' },
	  { userid: '17', password: 'Dynama' },
	  { userid: '18', password: 'DrIQ' },
	  { userid: '19', password: 'Magma' },
	  { userid: '20', password: 'Tornado' }
	]; 


	constructor(private formBuilder: FormBuilder,private router: Router, public authService: AuthService) { }

	ngOnInit() {
		 
		this.loginForm = this.formBuilder.group({
		  userid: ['', Validators.required],
		  password: ['', Validators.required]
		});
		this.returnUrl = '/dashboard';
		this.authService.logout();

	}

  // convenience getter for easy access to form fields
	get f() { return this.loginForm.controls; }

  

  login() {
	
    // stop here if form is invalid
    if (this.loginForm.invalid) {
        return;
    }
    else{
		 // if(this.f.userid.value == this.model.userid && this.f.password.value == this.model.password){
		
			try {
				let userName = this.f.userid.value;
				let user = this.HEROES.find( x => x.userid == userName );
		
				if( this.f.userid.value == user.userid && this.f.password.value == user.password){
					
					
					console.log("Login successful");
					//this.authService.authLogin(this.model);
					localStorage.setItem('isLoggedIn', "true");
					localStorage.setItem('token', this.f.userid.value);
					this.router.navigate([this.returnUrl]);
					
					
				}
				else{
					this.loginForm.reset();
					this.message = "Please check your userid and password";
				}
			} catch (error) {
				this.loginForm.reset();
				this.message = "Please check your userid and password";
			}
		
		}   
	}

}
