export class Hero {
  userid: string;
  password: string;
 
}